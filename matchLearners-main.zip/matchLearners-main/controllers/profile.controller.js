
module.exports = {
    getProfile(req,res){
        
    }

}